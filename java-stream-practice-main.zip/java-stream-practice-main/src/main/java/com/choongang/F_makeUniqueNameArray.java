package com.choongang;
import java.util.*;
import java.util.stream.Collectors;

public class F_makeUniqueNameArray {
    public String[] makeUniqueNameArray(List<String> names) {
        // TODO:

       return names.stream()
               .distinct()
               .sorted()
               .toArray(String[]::new);
    }
}















//        return names.stream().distinct().sorted().toArray((String[]::new));