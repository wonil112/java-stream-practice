package com.choongang;
import org.apache.commons.lang3.StringUtils;

import java.util.*;
import java.util.stream.Collectors;

public class E_computeAverageOfMaleMember {
    public double computeAverageOfMaleMember(List<Member> members) {
        // TODO:

        return members.stream()
                .filter(i -> i.gender.equals("Male"))
                .mapToDouble(i -> i.age)
                .average()
                .orElse(0);

    }

    static class Member {
        String name;
        String gender;
        int age;

        public Member(String name, String gender, int age) {
            this.name = name;
            this.gender = gender;
            this.age = age;
        }

        public String getName() {
            return name;
        }

        public String getGender() {
            return gender;
        }

        public int getAge() {
            return age;
        }
    }
}

// return members.stream().filter(i -> i.gender.equals("Male"))
//        .mapToDouble(i -> i.age)
//        .average().orElse(0);