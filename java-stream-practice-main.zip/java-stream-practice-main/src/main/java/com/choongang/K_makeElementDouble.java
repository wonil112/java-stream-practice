package com.choongang;
import java.util.*;
import java.util.stream.*;

public class K_makeElementDouble {
    public List<Integer> makeElementDouble(List<Integer> list) {
        // TODO:

        if(list.isEmpty()) {
            return list;
        }
       return list.stream().map(i -> i*2).collect(Collectors.toList());
    }
}
