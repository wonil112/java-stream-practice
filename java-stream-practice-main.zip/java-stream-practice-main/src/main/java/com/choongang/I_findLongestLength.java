package com.choongang;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class I_findLongestLength {
    public int findLongestLength(String[] strArr) {
        // TODO:

        if(strArr.length == 0) {
            return 0;
        }
        return Arrays.stream(strArr)
                .mapToInt(i -> i.length())
                .max()
                .orElse(0);
    }
}















//        if(strArr.length == 0) {
//        return 0;
//        }
//
//        return Arrays.stream(strArr).mapToInt(i -> i.length())
//        .max().orElse(0);