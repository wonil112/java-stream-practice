package com.choongang;
import java.util.*;

public class B_computeAverageOfNumbers {
    public double computeAverageOfNumbers(List<Integer> list) {
        // TODO:

        return list.stream()
                .mapToInt(number -> number)
                .average().orElse(0);
    }
}
















//        return list.stream().mapToDouble(i -> i).average().orElse(0);
//    }
//}
