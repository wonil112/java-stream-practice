package com.choongang;
import java.util.*;
import java.util.stream.IntStream;

public class H_findBiggestNumber {
    public Integer findBiggestNumber(int[] arr) {
        // TODO:

        if(arr.length == 0) {
            return null;
        }
        return IntStream.of(arr)
                .max()
                .orElse(0);
    }
}















//  if(arr.length == 0) {
//        return null;
//        }
//        return Arrays.stream(arr).max().orElse(0);