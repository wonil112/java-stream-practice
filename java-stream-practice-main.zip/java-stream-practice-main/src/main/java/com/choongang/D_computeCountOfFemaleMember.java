package com.choongang;
import java.util.*;

public class D_computeCountOfFemaleMember {
    public long computeCountOfFemaleMember(List<Member> members){
        // TODO:

       return members.stream()
                .filter(i -> i.gender.equals("Female"))
                .count();

    }

    static class Member {
        String name;
        String gender;

        public Member(String name, String gender) {
            this.name = name;
            this.gender = gender;
        }

        public String getName() {
            return name;
        }

        public String getGender() {
            return gender;
        }

    }
}

//  return members.stream().filter(i -> i.gender.equals("Female"))
//        .count();
