package com.choongang;
import java.util.*;

public class A_computeSumOfAllElements {
    public int computeSumOfAllElements(List<Integer> list) {
        // TODO:

        return list.stream()
                .mapToInt(number -> number)
                .sum();
    }
}

//        return list.stream().mapToInt(i -> i).sum();
//    }
//}
