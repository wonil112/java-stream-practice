package com.choongang;
import java.util.*;

public class L_isHot {
    public boolean isHot(int[] temperature) {
        // TODO:

        if (temperature.length != 7) {
            return false;
        }
        if (Arrays.stream(temperature)
                .filter(i -> i >= 30)
                .count() >= 3) {
            return true;
        } return false;
    }
}
